export enum VehicleStatus {
    Available = 'Available',
    InRepair = 'InRepair',
    Rented = 'Rented'
}