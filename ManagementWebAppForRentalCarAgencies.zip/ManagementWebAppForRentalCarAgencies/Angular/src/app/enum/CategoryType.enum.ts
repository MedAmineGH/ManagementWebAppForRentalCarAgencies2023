export enum CategoryType {
    Tourism = 'Tourism',
    Utility = 'Utility'
}