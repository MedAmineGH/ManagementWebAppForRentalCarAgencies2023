export enum Role {
    AGENCY = 'ROLE_AGENCY',
    CUSTOMER = 'ROLE_CUSTOMER'
}