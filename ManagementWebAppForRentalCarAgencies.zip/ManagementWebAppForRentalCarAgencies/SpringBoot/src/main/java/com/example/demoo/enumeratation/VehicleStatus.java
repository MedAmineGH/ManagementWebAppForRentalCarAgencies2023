package com.example.demoo.enumeratation;

public enum VehicleStatus {
    Available,
    InRepair,
    Rented
}
