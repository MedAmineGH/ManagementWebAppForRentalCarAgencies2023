package com.example.demoo.enumeratation;

public enum CategoryType {
    Utility,
    Tourism
}
