package com.example.demoo.constants;

public class UserImplementationConstant {
    public static final String USERNAME_ALREADY_EXISTS = "This username already exists";
    public static final String EMAIL_ALREADY_ASSOCIATED_TO_USER = "There's already a user associated to this email";
    public static final String USER_NOT_FOUND = "No User Found By Username : ";
    public static final String USER_ALREADY_EXISTS = "FOUND_USER_BY_USERNAME : ";
    public static final String EMPTY = "";
    public static final String USER_BY_EMAIL_NOT_FOUND = "There's no user associated with this email";
}
