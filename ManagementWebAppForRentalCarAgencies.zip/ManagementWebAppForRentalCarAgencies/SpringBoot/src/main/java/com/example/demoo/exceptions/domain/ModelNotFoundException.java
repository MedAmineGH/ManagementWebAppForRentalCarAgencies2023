package com.example.demoo.exceptions.domain;

public class ModelNotFoundException extends Exception {
    public ModelNotFoundException(String message) { super(message); }
}
